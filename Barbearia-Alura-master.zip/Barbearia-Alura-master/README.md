# Barbearia Alura 💇

Esse foi um projeto desenvolvido durante a primeira parte da Formação Front-end da Alura! 
O site contém as páginas de: <strong>home</strong>, <strong>produtos</strong> e <strong>contato</strong>.

A página <strong>home</strong> possui: 
<ul>
  <li>Informações sobre a barbearia Alura;</li>
  <li>Sobre o estabelecimento;</li>
  <li>Benefícios.</li>
</ul>
A página de <strong>produtos</strong> possui:
<ul>
  <li>Informações sobre os produtos;</li>
  <li>Preço sobre os produtos.</li>
</ul>
Já a última página de <strong>Contatos</strong> possui:
<ul>
  <li>Formulário de contato;</li>
  <li>Tabela de horários de funcionamento.</li>
</ul>

